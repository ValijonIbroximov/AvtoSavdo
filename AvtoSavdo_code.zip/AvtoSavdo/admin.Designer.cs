﻿using System.Drawing;

namespace AvtoSavdo
{
    partial class admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.malumotlarBazasiBilanBoglashToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Malumotlarbazasijoylashuvinikorish = new System.Windows.Forms.ToolStripMenuItem();
            this.parolniAlmashtirishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminOynasidanChiqishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picboxshowhide = new System.Windows.Forms.PictureBox();
            this.pnlehtiyotqismlar = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.picsettingshowhide = new System.Windows.Forms.PictureBox();
            this.pnlproductsettings = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnUpgrade = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlsetting = new System.Windows.Forms.Panel();
            this.btnxy = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.my = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.mx = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.mkategoriya = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.mizoh = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.mmavjud = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mrasmi = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.mnarxi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mnomi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.mid = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblsettingsarlavha = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxshowhide)).BeginInit();
            this.pnlehtiyotqismlar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsettingshowhide)).BeginInit();
            this.pnlproductsettings.SuspendLayout();
            this.pnlsetting.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mrasmi)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.malumotlarBazasiBilanBoglashToolStripMenuItem,
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem,
            this.Malumotlarbazasijoylashuvinikorish,
            this.parolniAlmashtirishToolStripMenuItem,
            this.adminOynasidanChiqishToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1070, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // malumotlarBazasiBilanBoglashToolStripMenuItem
            // 
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Name = "malumotlarBazasiBilanBoglashToolStripMenuItem";
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Size = new System.Drawing.Size(471, 32);
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Text = "Ma\'lumotlar bazasi bilan bog\'lash yoki almashtirish";
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Click += new System.EventHandler(this.malumotlarBazasiBilanBoglashToolStripMenuItem_Click);
            // 
            // yangiMalumotlarBazasiYaratishToolStripMenuItem
            // 
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Name = "yangiMalumotlarBazasiYaratishToolStripMenuItem";
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Size = new System.Drawing.Size(316, 32);
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Text = "Yangi ma\'lumotlar bazasi yaratish";
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Click += new System.EventHandler(this.yangiMalumotlarBazasiYaratishToolStripMenuItem_Click);
            // 
            // Malumotlarbazasijoylashuvinikorish
            // 
            this.Malumotlarbazasijoylashuvinikorish.Name = "Malumotlarbazasijoylashuvinikorish";
            this.Malumotlarbazasijoylashuvinikorish.Size = new System.Drawing.Size(363, 32);
            this.Malumotlarbazasijoylashuvinikorish.Text = "Ma\'lumotlar bazasi joylashuvini ko\'rish";
            this.Malumotlarbazasijoylashuvinikorish.Click += new System.EventHandler(this.Malumotlarbazasijoylashuvinikorish_Click);
            // 
            // parolniAlmashtirishToolStripMenuItem
            // 
            this.parolniAlmashtirishToolStripMenuItem.Name = "parolniAlmashtirishToolStripMenuItem";
            this.parolniAlmashtirishToolStripMenuItem.Size = new System.Drawing.Size(195, 32);
            this.parolniAlmashtirishToolStripMenuItem.Text = "Parolni almashtirish";
            this.parolniAlmashtirishToolStripMenuItem.Click += new System.EventHandler(this.parolniAlmashtirishToolStripMenuItem_Click);
            // 
            // adminOynasidanChiqishToolStripMenuItem
            // 
            this.adminOynasidanChiqishToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.adminOynasidanChiqishToolStripMenuItem.BackColor = System.Drawing.Color.LightCoral;
            this.adminOynasidanChiqishToolStripMenuItem.Name = "adminOynasidanChiqishToolStripMenuItem";
            this.adminOynasidanChiqishToolStripMenuItem.Size = new System.Drawing.Size(244, 32);
            this.adminOynasidanChiqishToolStripMenuItem.Text = "Admin oynasidan chiqish";
            this.adminOynasidanChiqishToolStripMenuItem.Click += new System.EventHandler(this.adminOynasidanChiqishToolStripMenuItem_Click);
            // 
            // picboxshowhide
            // 
            this.picboxshowhide.BackColor = System.Drawing.Color.Transparent;
            this.picboxshowhide.Dock = System.Windows.Forms.DockStyle.Left;
            this.picboxshowhide.Image = global::AvtoSavdo.Properties.Resources.strelkashowhide;
            this.picboxshowhide.Location = new System.Drawing.Point(300, 36);
            this.picboxshowhide.Name = "picboxshowhide";
            this.picboxshowhide.Size = new System.Drawing.Size(30, 644);
            this.picboxshowhide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picboxshowhide.TabIndex = 5;
            this.picboxshowhide.TabStop = false;
            this.picboxshowhide.Click += new System.EventHandler(this.picboxshowhide_Click);
            // 
            // pnlehtiyotqismlar
            // 
            this.pnlehtiyotqismlar.AutoScroll = true;
            this.pnlehtiyotqismlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlehtiyotqismlar.Controls.Add(this.label17);
            this.pnlehtiyotqismlar.Controls.Add(this.comboBox1);
            this.pnlehtiyotqismlar.Controls.Add(this.label13);
            this.pnlehtiyotqismlar.Controls.Add(this.textBox5);
            this.pnlehtiyotqismlar.Controls.Add(this.label12);
            this.pnlehtiyotqismlar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlehtiyotqismlar.Location = new System.Drawing.Point(0, 36);
            this.pnlehtiyotqismlar.Name = "pnlehtiyotqismlar";
            this.pnlehtiyotqismlar.Padding = new System.Windows.Forms.Padding(10);
            this.pnlehtiyotqismlar.Size = new System.Drawing.Size(300, 644);
            this.pnlehtiyotqismlar.TabIndex = 4;
            this.pnlehtiyotqismlar.Visible = false;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Location = new System.Drawing.Point(10, 100);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(280, 10);
            this.label17.TabIndex = 8;
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(10, 77);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(280, 23);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(140)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.label13.Dock = System.Windows.Forms.DockStyle.Top;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(10, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(280, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "Mahsulot kategoriyasi";
            this.label13.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox5.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(10, 30);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(280, 27);
            this.textBox5.TabIndex = 3;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(140)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(10, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(280, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "Qidirish";
            this.label12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // picsettingshowhide
            // 
            this.picsettingshowhide.BackColor = System.Drawing.Color.Transparent;
            this.picsettingshowhide.Dock = System.Windows.Forms.DockStyle.Right;
            this.picsettingshowhide.Image = global::AvtoSavdo.Properties.Resources.strelkashowhide;
            this.picsettingshowhide.Location = new System.Drawing.Point(740, 36);
            this.picsettingshowhide.Name = "picsettingshowhide";
            this.picsettingshowhide.Size = new System.Drawing.Size(30, 644);
            this.picsettingshowhide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picsettingshowhide.TabIndex = 7;
            this.picsettingshowhide.TabStop = false;
            this.picsettingshowhide.Click += new System.EventHandler(this.picsettingshowhide_Click);
            // 
            // pnlproductsettings
            // 
            this.pnlproductsettings.AutoScroll = true;
            this.pnlproductsettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlproductsettings.Controls.Add(this.btnDelete);
            this.pnlproductsettings.Controls.Add(this.label5);
            this.pnlproductsettings.Controls.Add(this.btnUpgrade);
            this.pnlproductsettings.Controls.Add(this.label4);
            this.pnlproductsettings.Controls.Add(this.btnClear);
            this.pnlproductsettings.Controls.Add(this.label3);
            this.pnlproductsettings.Controls.Add(this.btnAdd);
            this.pnlproductsettings.Controls.Add(this.label2);
            this.pnlproductsettings.Controls.Add(this.pnlsetting);
            this.pnlproductsettings.Controls.Add(this.label1);
            this.pnlproductsettings.Controls.Add(this.lblsettingsarlavha);
            this.pnlproductsettings.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlproductsettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pnlproductsettings.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlproductsettings.Location = new System.Drawing.Point(770, 36);
            this.pnlproductsettings.Name = "pnlproductsettings";
            this.pnlproductsettings.Padding = new System.Windows.Forms.Padding(10);
            this.pnlproductsettings.Size = new System.Drawing.Size(300, 644);
            this.pnlproductsettings.TabIndex = 6;
            this.pnlproductsettings.Visible = false;
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSize = true;
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(255)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.btnDelete.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(10, 695);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(259, 39);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "(x) O\'chirish";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Location = new System.Drawing.Point(10, 690);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(259, 5);
            this.label5.TabIndex = 10;
            // 
            // btnUpgrade
            // 
            this.btnUpgrade.AutoSize = true;
            this.btnUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.btnUpgrade.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpgrade.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpgrade.Location = new System.Drawing.Point(10, 651);
            this.btnUpgrade.Name = "btnUpgrade";
            this.btnUpgrade.Size = new System.Drawing.Size(259, 39);
            this.btnUpgrade.TabIndex = 4;
            this.btnUpgrade.Text = "(^) Yangilash";
            this.btnUpgrade.UseVisualStyleBackColor = false;
            this.btnUpgrade.Click += new System.EventHandler(this.btnUpgrade_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Location = new System.Drawing.Point(10, 646);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(259, 5);
            this.label4.TabIndex = 9;
            // 
            // btnClear
            // 
            this.btnClear.AutoSize = true;
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnClear.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(10, 607);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(259, 39);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "( ) Tozalash";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(10, 602);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(259, 5);
            this.label3.TabIndex = 8;
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSize = true;
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Lucida Sans Typewriter", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(10, 563);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(259, 39);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "(+) Qo\'shish";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(10, 553);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 10);
            this.label2.TabIndex = 7;
            // 
            // pnlsetting
            // 
            this.pnlsetting.AutoSize = true;
            this.pnlsetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(140)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.pnlsetting.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlsetting.Controls.Add(this.btnxy);
            this.pnlsetting.Controls.Add(this.panel2);
            this.pnlsetting.Controls.Add(this.panel1);
            this.pnlsetting.Controls.Add(this.label14);
            this.pnlsetting.Controls.Add(this.mkategoriya);
            this.pnlsetting.Controls.Add(this.label11);
            this.pnlsetting.Controls.Add(this.mizoh);
            this.pnlsetting.Controls.Add(this.label10);
            this.pnlsetting.Controls.Add(this.mmavjud);
            this.pnlsetting.Controls.Add(this.label9);
            this.pnlsetting.Controls.Add(this.mrasmi);
            this.pnlsetting.Controls.Add(this.label8);
            this.pnlsetting.Controls.Add(this.mnarxi);
            this.pnlsetting.Controls.Add(this.label7);
            this.pnlsetting.Controls.Add(this.mnomi);
            this.pnlsetting.Controls.Add(this.label6);
            this.pnlsetting.Controls.Add(this.mid);
            this.pnlsetting.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlsetting.Location = new System.Drawing.Point(10, 93);
            this.pnlsetting.Name = "pnlsetting";
            this.pnlsetting.Padding = new System.Windows.Forms.Padding(3);
            this.pnlsetting.Size = new System.Drawing.Size(259, 460);
            this.pnlsetting.TabIndex = 1;
            // 
            // btnxy
            // 
            this.btnxy.AutoSize = true;
            this.btnxy.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnxy.Location = new System.Drawing.Point(3, 428);
            this.btnxy.Name = "btnxy";
            this.btnxy.Size = new System.Drawing.Size(251, 27);
            this.btnxy.TabIndex = 6;
            this.btnxy.Text = "Joylashuv belgilash";
            this.btnxy.UseVisualStyleBackColor = true;
            this.btnxy.Click += new System.EventHandler(this.btnxy_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.my);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 403);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(251, 25);
            this.panel2.TabIndex = 13;
            // 
            // my
            // 
            this.my.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.my.Dock = System.Windows.Forms.DockStyle.Fill;
            this.my.Font = new System.Drawing.Font("Lucida Sans Typewriter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.my.Location = new System.Drawing.Point(35, 0);
            this.my.MaxLength = 26;
            this.my.Name = "my";
            this.my.Size = new System.Drawing.Size(214, 23);
            this.my.TabIndex = 0;
            this.my.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Dock = System.Windows.Forms.DockStyle.Left;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 23);
            this.label16.TabIndex = 12;
            this.label16.Text = "y = ";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.mx);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 378);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 25);
            this.panel1.TabIndex = 12;
            // 
            // mx
            // 
            this.mx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mx.Font = new System.Drawing.Font("Lucida Sans Typewriter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mx.Location = new System.Drawing.Point(35, 0);
            this.mx.MaxLength = 26;
            this.mx.Name = "mx";
            this.mx.Size = new System.Drawing.Size(214, 23);
            this.mx.TabIndex = 0;
            this.mx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Dock = System.Windows.Forms.DockStyle.Left;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 23);
            this.label15.TabIndex = 12;
            this.label15.Text = "x = ";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(3, 358);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(251, 20);
            this.label14.TabIndex = 11;
            this.label14.Text = "Mahsulot joylashuvi";
            this.label14.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mkategoriya
            // 
            this.mkategoriya.Dock = System.Windows.Forms.DockStyle.Top;
            this.mkategoriya.Font = new System.Drawing.Font("Lucida Sans Typewriter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mkategoriya.FormattingEnabled = true;
            this.mkategoriya.Location = new System.Drawing.Point(3, 335);
            this.mkategoriya.Name = "mkategoriya";
            this.mkategoriya.Size = new System.Drawing.Size(251, 23);
            this.mkategoriya.Sorted = true;
            this.mkategoriya.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(3, 315);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(251, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "Mahsulot kategoriyasi";
            this.label11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mizoh
            // 
            this.mizoh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mizoh.Dock = System.Windows.Forms.DockStyle.Top;
            this.mizoh.Font = new System.Drawing.Font("Lucida Sans Typewriter", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mizoh.Location = new System.Drawing.Point(3, 280);
            this.mizoh.MaxLength = 255;
            this.mizoh.Multiline = true;
            this.mizoh.Name = "mizoh";
            this.mizoh.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mizoh.Size = new System.Drawing.Size(251, 35);
            this.mizoh.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(3, 260);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(251, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "Mahsulot haqida izoh";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mmavjud
            // 
            this.mmavjud.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mmavjud.Dock = System.Windows.Forms.DockStyle.Top;
            this.mmavjud.Font = new System.Drawing.Font("Lucida Sans Typewriter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mmavjud.Location = new System.Drawing.Point(3, 237);
            this.mmavjud.MaxLength = 26;
            this.mmavjud.Name = "mmavjud";
            this.mmavjud.Size = new System.Drawing.Size(251, 23);
            this.mmavjud.TabIndex = 3;
            this.mmavjud.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mmavjud.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mmavjud_KeyPress);
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(3, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(251, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "Mahsulot soni (Mavjud)";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mrasmi
            // 
            this.mrasmi.BackColor = System.Drawing.Color.White;
            this.mrasmi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mrasmi.Dock = System.Windows.Forms.DockStyle.Top;
            this.mrasmi.Location = new System.Drawing.Point(3, 147);
            this.mrasmi.Name = "mrasmi";
            this.mrasmi.Size = new System.Drawing.Size(251, 70);
            this.mrasmi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mrasmi.TabIndex = 5;
            this.mrasmi.TabStop = false;
            this.mrasmi.DoubleClick += new System.EventHandler(this.mrasmi_DoubleClick);
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(3, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(251, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Mahsulot rasmi";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mnarxi
            // 
            this.mnarxi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mnarxi.Dock = System.Windows.Forms.DockStyle.Top;
            this.mnarxi.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnarxi.Location = new System.Drawing.Point(3, 100);
            this.mnarxi.MaxLength = 26;
            this.mnarxi.Name = "mnarxi";
            this.mnarxi.Size = new System.Drawing.Size(251, 27);
            this.mnarxi.TabIndex = 2;
            this.mnarxi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mnarxi.TextChanged += new System.EventHandler(this.mnarxi_TextChanged);
            this.mnarxi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mnarxi_KeyPress);
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(3, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(251, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Mahsulot narxi";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mnomi
            // 
            this.mnomi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mnomi.Dock = System.Windows.Forms.DockStyle.Top;
            this.mnomi.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnomi.Location = new System.Drawing.Point(3, 35);
            this.mnomi.Multiline = true;
            this.mnomi.Name = "mnomi";
            this.mnomi.Size = new System.Drawing.Size(251, 45);
            this.mnomi.TabIndex = 1;
            this.mnomi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(3, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(251, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Mahsulot nomi";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // mid
            // 
            this.mid.Dock = System.Windows.Forms.DockStyle.Top;
            this.mid.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mid.Location = new System.Drawing.Point(3, 3);
            this.mid.Name = "mid";
            this.mid.Size = new System.Drawing.Size(251, 12);
            this.mid.TabIndex = 14;
            this.mid.Text = "ID: ";
            this.mid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(10, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 10);
            this.label1.TabIndex = 1;
            // 
            // lblsettingsarlavha
            // 
            this.lblsettingsarlavha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(140)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lblsettingsarlavha.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblsettingsarlavha.Font = new System.Drawing.Font("Lucida Sans Unicode", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsettingsarlavha.ForeColor = System.Drawing.Color.White;
            this.lblsettingsarlavha.Location = new System.Drawing.Point(10, 10);
            this.lblsettingsarlavha.Name = "lblsettingsarlavha";
            this.lblsettingsarlavha.Size = new System.Drawing.Size(259, 73);
            this.lblsettingsarlavha.TabIndex = 0;
            this.lblsettingsarlavha.Text = "Mahsulot\r\nsozlamalari";
            this.lblsettingsarlavha.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::AvtoSavdo.Properties.Resources._157019460811;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1070, 680);
            this.Controls.Add(this.picsettingshowhide);
            this.Controls.Add(this.pnlproductsettings);
            this.Controls.Add(this.picboxshowhide);
            this.Controls.Add(this.pnlehtiyotqismlar);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.MaximizeBox = false;
            this.Name = "admin";
            this.Text = "admin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.admin_FormClosing);
            this.Load += new System.EventHandler(this.admin_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.admin_KeyPress);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.admin_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxshowhide)).EndInit();
            this.pnlehtiyotqismlar.ResumeLayout(false);
            this.pnlehtiyotqismlar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsettingshowhide)).EndInit();
            this.pnlproductsettings.ResumeLayout(false);
            this.pnlproductsettings.PerformLayout();
            this.pnlsetting.ResumeLayout(false);
            this.pnlsetting.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mrasmi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem malumotlarBazasiBilanBoglashToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yangiMalumotlarBazasiYaratishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminOynasidanChiqishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parolniAlmashtirishToolStripMenuItem;
        private System.Windows.Forms.PictureBox picboxshowhide;
        private System.Windows.Forms.Panel pnlehtiyotqismlar;
        private System.Windows.Forms.PictureBox picsettingshowhide;
        private System.Windows.Forms.Panel pnlproductsettings;
        private System.Windows.Forms.Label lblsettingsarlavha;
        private System.Windows.Forms.Panel pnlsetting;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnUpgrade;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox mnomi;
        private System.Windows.Forms.TextBox mnarxi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox mrasmi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox mmavjud;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox mizoh;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox mkategoriya;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnxy;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox my;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox mx;
        private System.Windows.Forms.Label mid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ToolStripMenuItem Malumotlarbazasijoylashuvinikorish;
    }
}